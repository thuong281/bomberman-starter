package uet.oop.bomberman.constants;

public enum Dimension {
    VERTICAL, HORIZONTAL, CENTER
}
