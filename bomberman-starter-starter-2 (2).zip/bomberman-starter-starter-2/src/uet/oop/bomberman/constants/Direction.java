package uet.oop.bomberman.constants;

public enum  Direction {
    UP, DOWN, LEFT, RIGHT
}
